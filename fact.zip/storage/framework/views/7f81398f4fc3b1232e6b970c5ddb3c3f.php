<?php
if (!function_exists('_7f81398f4fc3b1232e6b970c5ddb3c3f')):
function _7f81398f4fc3b1232e6b970c5ddb3c3f($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'name' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
unset($__defaults);
?>

<?php
// We only want to show the name attribute on the checkbox if it has been set
// manually, but not if it has been set from the wire:model attribute...
$showName = isset($name);

if (! isset($name)) {
    $name = $attributes->whereStartsWith('wire:model')->first();
}

$classes = Flux::classes()
    ->add('flex size-[1.125rem] rounded-[.3rem] mt-px outline-offset-2')
    ;
?>

<?php if (!function_exists('_79b6150b8688b167fa5e2850e4c623da')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/with-inline-field.blade.php', $__blaze->compiledPath.'/79b6150b8688b167fa5e2850e4c623da.php'); require $__blaze->compiledPath.'/79b6150b8688b167fa5e2850e4c623da.php'; } ?>
<?php if (isset($__slots79b6150b8688b167fa5e2850e4c623da)) { $__slotsStack79b6150b8688b167fa5e2850e4c623da[] = $__slots79b6150b8688b167fa5e2850e4c623da; } ?>
<?php if (isset($__attrs79b6150b8688b167fa5e2850e4c623da)) { $__attrsStack79b6150b8688b167fa5e2850e4c623da[] = $__attrs79b6150b8688b167fa5e2850e4c623da; } ?>
<?php $__attrs79b6150b8688b167fa5e2850e4c623da = ['attributes' => $attributes]; ?>
<?php $__slots79b6150b8688b167fa5e2850e4c623da = []; ?>
<?php $__blaze->pushData($__attrs79b6150b8688b167fa5e2850e4c623da); ?>
<?php ob_start(); ?>
    <ui-checkbox <?php echo e($attributes->class($classes)); ?> <?php if($showName): ?> name="<?php echo e($name); ?>" <?php endif; ?> data-flux-control data-flux-checkbox>
        <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::checkbox.indicator", []); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php if (!function_exists('_5ad343798dae466365e6048ab3013d59')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/checkbox/indicator.blade.php', $__blaze->compiledPath.'/5ad343798dae466365e6048ab3013d59.php'); require $__blaze->compiledPath.'/5ad343798dae466365e6048ab3013d59.php'; } ?>
<?php $__blaze->pushData([]); ?>
<?php _5ad343798dae466365e6048ab3013d59($__blaze, [], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
    </ui-checkbox>
<?php $__slots79b6150b8688b167fa5e2850e4c623da['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots79b6150b8688b167fa5e2850e4c623da); ?>
<?php _79b6150b8688b167fa5e2850e4c623da($__blaze, $__attrs79b6150b8688b167fa5e2850e4c623da, $__slots79b6150b8688b167fa5e2850e4c623da, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack79b6150b8688b167fa5e2850e4c623da)) { $__slots79b6150b8688b167fa5e2850e4c623da = array_pop($__slotsStack79b6150b8688b167fa5e2850e4c623da); } ?>
<?php if (! empty($__attrsStack79b6150b8688b167fa5e2850e4c623da)) { $__attrs79b6150b8688b167fa5e2850e4c623da = array_pop($__attrsStack79b6150b8688b167fa5e2850e4c623da); } ?>
<?php $__blaze->popData(); ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/checkbox/variants/default.blade.php ENDPATH**/ ?>
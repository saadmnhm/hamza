<?php
if (!function_exists('_ed8cd0ef7e07286c70a0e0a495689b26')):
function _ed8cd0ef7e07286c70a0e0a495689b26($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php $tooltipPosition = $tooltipPosition ??= $attributes->pluck('tooltip:position'); ?>
<?php $tooltipKbd = $tooltipKbd ??= $attributes->pluck('tooltip:kbd'); ?>
<?php $tooltip = $tooltip ??= $attributes->pluck('tooltip'); ?>
<?php $iconTrailing ??= $attributes->pluck('icon:trailing'); ?>
<?php $iconVariant ??= $attributes->pluck('icon:variant'); ?>

<?php
$__defaults = [
    'tooltipPosition' => 'right',
    'tooltipKbd' => null,
    'tooltip' => null,
    'iconVariant' => 'outline',
    'iconTrailing' => null,
    'badgeColor' => null,
    'iconDot' => null,
    'accent' => true,
    'badge' => null,
    'icon' => null,
];
$tooltipPosition ??= $attributes['tooltip-position'] ?? $attributes['tooltipPosition'] ?? $__defaults['tooltipPosition']; unset($attributes['tooltipPosition'], $attributes['tooltip-position']);
$tooltipKbd ??= $attributes['tooltip-kbd'] ?? $attributes['tooltipKbd'] ?? $__defaults['tooltipKbd']; unset($attributes['tooltipKbd'], $attributes['tooltip-kbd']);
$tooltip ??= $attributes['tooltip'] ?? $__defaults['tooltip']; unset($attributes['tooltip']);
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$iconTrailing ??= $attributes['icon-trailing'] ?? $attributes['iconTrailing'] ?? $__defaults['iconTrailing']; unset($attributes['iconTrailing'], $attributes['icon-trailing']);
$badgeColor ??= $attributes['badge-color'] ?? $attributes['badgeColor'] ?? $__defaults['badgeColor']; unset($attributes['badgeColor'], $attributes['badge-color']);
$iconDot ??= $attributes['icon-dot'] ?? $attributes['iconDot'] ?? $__defaults['iconDot']; unset($attributes['iconDot'], $attributes['icon-dot']);
$accent ??= $attributes['accent'] ?? $__defaults['accent']; unset($attributes['accent']);
$badge ??= $attributes['badge'] ?? $__defaults['badge']; unset($attributes['badge']);
$icon ??= $attributes['icon'] ?? $__defaults['icon']; unset($attributes['icon']);
unset($__defaults);
?>

<?php
// Slots contain rendered HTML (including conditional comments) and encoded entities.
// Tooltips should mirror only the visible text.
$tooltip ??= $slot->isNotEmpty()
    ? trim(html_entity_decode(strip_tags((string) $slot), ENT_QUOTES | ENT_HTML5, 'UTF-8'))
    : null;

// Size-up icons in square/icon-only buttons...
$iconClasses = Flux::classes('size-4')
    ->add('in-data-flux-sidebar-group-dropdown:text-zinc-400! dark:in-data-flux-sidebar-group-dropdown:text-white/80!')
    ->add('[[data-flux-sidebar-item]:hover_&]:text-current!')
    ->add('[[data-flux-sidebar-item][data-active]_&]:text-current!');

$classes = Flux::classes()
    ->add('h-8 in-data-flux-sidebar-on-mobile:h-10 relative flex items-center gap-3 rounded-lg')
    ->add('in-data-flux-sidebar-collapsed-desktop:w-10 in-data-flux-sidebar-collapsed-desktop:justify-center')
    ->add('py-0 text-start w-full px-3 has-data-flux-navlist-badge:not-in-data-flux-sidebar-collapsed-desktop:pe-1.5 my-px')
    ->add('text-zinc-500 dark:text-white/80')
    ->add(match ($accent) {
        true => [
            'data-current:text-(--color-accent-content) hover:data-current:text-(--color-accent-content)',
            'data-current:bg-white dark:data-current:bg-white/[7%] data-current:border data-current:border-zinc-200 dark:data-current:border-transparent',
            'hover:text-zinc-800 dark:hover:text-white dark:hover:bg-white/[7%] hover:bg-zinc-800/5 ',
            'border border-transparent',
        ],
        false => [
            'data-current:text-zinc-800 dark:data-current:text-zinc-100 data-current:border-zinc-200',
            'data-current:bg-white dark:data-current:bg-white/10 data-current:border data-current:border-zinc-200 dark:data-current:border-white/10 data-current:shadow-xs',
            'hover:text-zinc-800 dark:hover:text-white',
        ],
    })
    // Override the default styles to match dropdowns for when the item is inside a collapsed group dropdown...
    ->add('in-data-flux-sidebar-group-dropdown:w-auto! in-data-flux-sidebar-group-dropdown:px-2!')
    ->add('in-data-flux-sidebar-group-dropdown:focus:outline-hidden!')
    ->add('in-data-flux-sidebar-group-dropdown:text-zinc-800! in-data-flux-sidebar-group-dropdown:bg-white! in-data-flux-sidebar-group-dropdown:hover:bg-zinc-50!')
    ->add('in-data-flux-sidebar-group-dropdown:data-active:bg-zinc-50!')
    ->add('dark:in-data-flux-sidebar-group-dropdown:text-white! dark:in-data-flux-sidebar-group-dropdown:bg-transparent! dark:in-data-flux-sidebar-group-dropdown:hover:bg-zinc-600! dark:in-data-flux-sidebar-group-dropdown:data-active:bg-zinc-600!')
    ;
?>

<?php if (!function_exists('_ac410b79ba3d50b8945b218f9d70a7ea')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php', $__blaze->compiledPath.'/ac410b79ba3d50b8945b218f9d70a7ea.php'); require $__blaze->compiledPath.'/ac410b79ba3d50b8945b218f9d70a7ea.php'; } ?>
<?php if (isset($__slotsac410b79ba3d50b8945b218f9d70a7ea)) { $__slotsStackac410b79ba3d50b8945b218f9d70a7ea[] = $__slotsac410b79ba3d50b8945b218f9d70a7ea; } ?>
<?php if (isset($__attrsac410b79ba3d50b8945b218f9d70a7ea)) { $__attrsStackac410b79ba3d50b8945b218f9d70a7ea[] = $__attrsac410b79ba3d50b8945b218f9d70a7ea; } ?>
<?php $__attrsac410b79ba3d50b8945b218f9d70a7ea = ['position' => $tooltipPosition,'class' => 'block min-w-0']; ?>
<?php $__slotsac410b79ba3d50b8945b218f9d70a7ea = []; ?>
<?php $__blaze->pushData($__attrsac410b79ba3d50b8945b218f9d70a7ea); ?>
<?php ob_start(); ?>
    <?php if (!function_exists('_c83a730144ebf9cbf89047a8bb24f2de')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/button-or-link.blade.php', $__blaze->compiledPath.'/c83a730144ebf9cbf89047a8bb24f2de.php'); require $__blaze->compiledPath.'/c83a730144ebf9cbf89047a8bb24f2de.php'; } ?>
<?php if (isset($__slotsc83a730144ebf9cbf89047a8bb24f2de)) { $__slotsStackc83a730144ebf9cbf89047a8bb24f2de[] = $__slotsc83a730144ebf9cbf89047a8bb24f2de; } ?>
<?php if (isset($__attrsc83a730144ebf9cbf89047a8bb24f2de)) { $__attrsStackc83a730144ebf9cbf89047a8bb24f2de[] = $__attrsc83a730144ebf9cbf89047a8bb24f2de; } ?>
<?php $__attrsc83a730144ebf9cbf89047a8bb24f2de = ['attributes' => $attributes->class($classes),'dataFluxSidebarItem' => true]; ?>
<?php $__slotsc83a730144ebf9cbf89047a8bb24f2de = []; ?>
<?php $__blaze->pushData($__attrsc83a730144ebf9cbf89047a8bb24f2de); ?>
<?php ob_start(); ?>
        <?php if ($icon): ?>
            <div class="relative">
                <?php if (is_string($icon) && $icon !== ''): ?>
                    <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::icon", ['icon' => $icon, 'variant' => $iconVariant, 'class' => $iconClasses]); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php if (!function_exists('_b818240420d205fb85c457a5f0251124')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/b818240420d205fb85c457a5f0251124.php'); require $__blaze->compiledPath.'/b818240420d205fb85c457a5f0251124.php'; } ?>
<?php $__blaze->pushData(['icon' => $icon,'variant' => $iconVariant,'class' => $iconClasses]); ?>
<?php _b818240420d205fb85c457a5f0251124($__blaze, ['icon' => $icon,'variant' => $iconVariant,'class' => $iconClasses], [], ['icon', 'variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
                <?php else: ?>
                    <?php echo e($icon); ?>

                <?php endif; ?>

                <?php if ($iconDot): ?>
                    <div class="absolute top-[-2px] end-[-2px]">
                        <div class="size-[6px] rounded-full bg-zinc-500 dark:bg-zinc-400"></div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if ($slot->isNotEmpty()): ?>
            <div class="
                in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden
                flex-1 text-sm font-medium truncate [[data-nav-footer]_&]:hidden [[data-nav-sidebar]_[data-nav-footer]_&]:block" data-content><?php echo e($slot); ?></div>
        <?php endif; ?>

        <?php if (is_string($iconTrailing) && $iconTrailing !== ''): ?>
            <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::icon", ['icon' => $iconTrailing, 'variant' => $iconVariant, 'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden size-4!']); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php if (!function_exists('_b818240420d205fb85c457a5f0251124')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/b818240420d205fb85c457a5f0251124.php'); require $__blaze->compiledPath.'/b818240420d205fb85c457a5f0251124.php'; } ?>
<?php $__blaze->pushData(['icon' => $iconTrailing,'variant' => $iconVariant,'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden size-4!']); ?>
<?php _b818240420d205fb85c457a5f0251124($__blaze, ['icon' => $iconTrailing,'variant' => $iconVariant,'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden size-4!'], [], ['icon', 'variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
        <?php elseif ($iconTrailing): ?>
            <?php echo e($iconTrailing); ?>

        <?php endif; ?>

        <?php if (isset($badge) && $badge !== ''): ?>
            <?php $badgeAttributes = Flux::attributesAfter('badge:', $attributes, ['color' => $badgeColor]); ?>
            <?php if (!function_exists('_6079a4830402a60a985bb34cce0a2ae1')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/badge.blade.php', $__blaze->compiledPath.'/6079a4830402a60a985bb34cce0a2ae1.php'); require $__blaze->compiledPath.'/6079a4830402a60a985bb34cce0a2ae1.php'; } ?>
<?php if (isset($__slots6079a4830402a60a985bb34cce0a2ae1)) { $__slotsStack6079a4830402a60a985bb34cce0a2ae1[] = $__slots6079a4830402a60a985bb34cce0a2ae1; } ?>
<?php if (isset($__attrs6079a4830402a60a985bb34cce0a2ae1)) { $__attrsStack6079a4830402a60a985bb34cce0a2ae1[] = $__attrs6079a4830402a60a985bb34cce0a2ae1; } ?>
<?php $__attrs6079a4830402a60a985bb34cce0a2ae1 = ['attributes' => $badgeAttributes,'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden']; ?>
<?php $__slots6079a4830402a60a985bb34cce0a2ae1 = []; ?>
<?php $__blaze->pushData($__attrs6079a4830402a60a985bb34cce0a2ae1); ?>
<?php ob_start(); ?><?php echo e($badge); ?><?php $__slots6079a4830402a60a985bb34cce0a2ae1['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots6079a4830402a60a985bb34cce0a2ae1); ?>
<?php _6079a4830402a60a985bb34cce0a2ae1($__blaze, $__attrs6079a4830402a60a985bb34cce0a2ae1, $__slots6079a4830402a60a985bb34cce0a2ae1, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack6079a4830402a60a985bb34cce0a2ae1)) { $__slots6079a4830402a60a985bb34cce0a2ae1 = array_pop($__slotsStack6079a4830402a60a985bb34cce0a2ae1); } ?>
<?php if (! empty($__attrsStack6079a4830402a60a985bb34cce0a2ae1)) { $__attrs6079a4830402a60a985bb34cce0a2ae1 = array_pop($__attrsStack6079a4830402a60a985bb34cce0a2ae1); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    <?php $__slotsc83a730144ebf9cbf89047a8bb24f2de['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsc83a730144ebf9cbf89047a8bb24f2de); ?>
<?php _c83a730144ebf9cbf89047a8bb24f2de($__blaze, $__attrsc83a730144ebf9cbf89047a8bb24f2de, $__slotsc83a730144ebf9cbf89047a8bb24f2de, ['attributes', 'dataFluxSidebarItem'], ['dataFluxSidebarItem' => 'data-flux-sidebar-item'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackc83a730144ebf9cbf89047a8bb24f2de)) { $__slotsc83a730144ebf9cbf89047a8bb24f2de = array_pop($__slotsStackc83a730144ebf9cbf89047a8bb24f2de); } ?>
<?php if (! empty($__attrsStackc83a730144ebf9cbf89047a8bb24f2de)) { $__attrsc83a730144ebf9cbf89047a8bb24f2de = array_pop($__attrsStackc83a730144ebf9cbf89047a8bb24f2de); } ?>
<?php $__blaze->popData(); ?>

    <?php if (!function_exists('_fa0e7487655a9e66f92affc98c01d082')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/content.blade.php', $__blaze->compiledPath.'/fa0e7487655a9e66f92affc98c01d082.php'); require $__blaze->compiledPath.'/fa0e7487655a9e66f92affc98c01d082.php'; } ?>
<?php if (isset($__slotsfa0e7487655a9e66f92affc98c01d082)) { $__slotsStackfa0e7487655a9e66f92affc98c01d082[] = $__slotsfa0e7487655a9e66f92affc98c01d082; } ?>
<?php if (isset($__attrsfa0e7487655a9e66f92affc98c01d082)) { $__attrsStackfa0e7487655a9e66f92affc98c01d082[] = $__attrsfa0e7487655a9e66f92affc98c01d082; } ?>
<?php $__attrsfa0e7487655a9e66f92affc98c01d082 = ['kbd' => $tooltipKbd,'class' => 'not-in-data-flux-sidebar-collapsed-desktop:hidden in-data-flux-sidebar-group-dropdown:hidden cursor-default']; ?>
<?php $__slotsfa0e7487655a9e66f92affc98c01d082 = []; ?>
<?php $__blaze->pushData($__attrsfa0e7487655a9e66f92affc98c01d082); ?>
<?php ob_start(); ?>
        <?php echo e($tooltip); ?>

    <?php $__slotsfa0e7487655a9e66f92affc98c01d082['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsfa0e7487655a9e66f92affc98c01d082); ?>
<?php _fa0e7487655a9e66f92affc98c01d082($__blaze, $__attrsfa0e7487655a9e66f92affc98c01d082, $__slotsfa0e7487655a9e66f92affc98c01d082, ['kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackfa0e7487655a9e66f92affc98c01d082)) { $__slotsfa0e7487655a9e66f92affc98c01d082 = array_pop($__slotsStackfa0e7487655a9e66f92affc98c01d082); } ?>
<?php if (! empty($__attrsStackfa0e7487655a9e66f92affc98c01d082)) { $__attrsfa0e7487655a9e66f92affc98c01d082 = array_pop($__attrsStackfa0e7487655a9e66f92affc98c01d082); } ?>
<?php $__blaze->popData(); ?>
<?php $__slotsac410b79ba3d50b8945b218f9d70a7ea['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsac410b79ba3d50b8945b218f9d70a7ea); ?>
<?php _ac410b79ba3d50b8945b218f9d70a7ea($__blaze, $__attrsac410b79ba3d50b8945b218f9d70a7ea, $__slotsac410b79ba3d50b8945b218f9d70a7ea, ['position'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackac410b79ba3d50b8945b218f9d70a7ea)) { $__slotsac410b79ba3d50b8945b218f9d70a7ea = array_pop($__slotsStackac410b79ba3d50b8945b218f9d70a7ea); } ?>
<?php if (! empty($__attrsStackac410b79ba3d50b8945b218f9d70a7ea)) { $__attrsac410b79ba3d50b8945b218f9d70a7ea = array_pop($__attrsStackac410b79ba3d50b8945b218f9d70a7ea); } ?>
<?php $__blaze->popData(); ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php ENDPATH**/ ?>
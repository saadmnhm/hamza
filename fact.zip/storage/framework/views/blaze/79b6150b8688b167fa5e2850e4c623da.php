<?php
if (!function_exists('__79b6150b8688b167fa5e2850e4c623da')):
function __79b6150b8688b167fa5e2850e4c623da($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedattributes($attributes, [
    'name',
    'description',
    'label',
]));
?>

<?php
$__defaults = [
    'name' => $attributes->whereStartsWith('wire:model')->first(),
    'description' => null,
    'label' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
$description ??= $attributes['description'] ?? $__defaults['description']; unset($attributes['description']);
$label ??= $attributes['label'] ?? $__defaults['label']; unset($attributes['label']);
unset($__defaults);
?>

<?php if (isset($label) || isset($description)): ?>
    <?php if (!function_exists('__0987649927eebf2ef59dcf0475420130')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php', $__blaze->compiledPath.'/0987649927eebf2ef59dcf0475420130.php'); require $__blaze->compiledPath.'/0987649927eebf2ef59dcf0475420130.php'; } ?>
<?php if (isset($__slots0987649927eebf2ef59dcf0475420130)) { $__slotsStack0987649927eebf2ef59dcf0475420130[] = $__slots0987649927eebf2ef59dcf0475420130; } ?>
<?php if (isset($__attrs0987649927eebf2ef59dcf0475420130)) { $__attrsStack0987649927eebf2ef59dcf0475420130[] = $__attrs0987649927eebf2ef59dcf0475420130; } ?>
<?php $__attrs0987649927eebf2ef59dcf0475420130 = ['variant' => 'inline']; ?>
<?php $__slots0987649927eebf2ef59dcf0475420130 = []; ?>
<?php $__blaze->pushData($__attrs0987649927eebf2ef59dcf0475420130); ?>
<?php ob_start(); ?>
        <?php echo e($slot); ?>


        <?php if (isset($label)): ?>
            <?php if (!function_exists('__9017229a7ef12f992d2ffffd18157a3b')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php', $__blaze->compiledPath.'/9017229a7ef12f992d2ffffd18157a3b.php'); require $__blaze->compiledPath.'/9017229a7ef12f992d2ffffd18157a3b.php'; } ?>
<?php if (isset($__slots9017229a7ef12f992d2ffffd18157a3b)) { $__slotsStack9017229a7ef12f992d2ffffd18157a3b[] = $__slots9017229a7ef12f992d2ffffd18157a3b; } ?>
<?php if (isset($__attrs9017229a7ef12f992d2ffffd18157a3b)) { $__attrsStack9017229a7ef12f992d2ffffd18157a3b[] = $__attrs9017229a7ef12f992d2ffffd18157a3b; } ?>
<?php $__attrs9017229a7ef12f992d2ffffd18157a3b = []; ?>
<?php $__slots9017229a7ef12f992d2ffffd18157a3b = []; ?>
<?php $__blaze->pushData($__attrs9017229a7ef12f992d2ffffd18157a3b); ?>
<?php ob_start(); ?><?php echo e($label); ?><?php $__slots9017229a7ef12f992d2ffffd18157a3b['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots9017229a7ef12f992d2ffffd18157a3b); ?>
<?php __9017229a7ef12f992d2ffffd18157a3b($__blaze, $__attrs9017229a7ef12f992d2ffffd18157a3b, $__slots9017229a7ef12f992d2ffffd18157a3b, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9017229a7ef12f992d2ffffd18157a3b)) { $__slots9017229a7ef12f992d2ffffd18157a3b = array_pop($__slotsStack9017229a7ef12f992d2ffffd18157a3b); } ?>
<?php if (! empty($__attrsStack9017229a7ef12f992d2ffffd18157a3b)) { $__attrs9017229a7ef12f992d2ffffd18157a3b = array_pop($__attrsStack9017229a7ef12f992d2ffffd18157a3b); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php if (isset($description)): ?>
            <?php if (!function_exists('__9f7e6fbbc13e4ec29ea75e483e145890')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/9f7e6fbbc13e4ec29ea75e483e145890.php'); require $__blaze->compiledPath.'/9f7e6fbbc13e4ec29ea75e483e145890.php'; } ?>
<?php if (isset($__slots9f7e6fbbc13e4ec29ea75e483e145890)) { $__slotsStack9f7e6fbbc13e4ec29ea75e483e145890[] = $__slots9f7e6fbbc13e4ec29ea75e483e145890; } ?>
<?php if (isset($__attrs9f7e6fbbc13e4ec29ea75e483e145890)) { $__attrsStack9f7e6fbbc13e4ec29ea75e483e145890[] = $__attrs9f7e6fbbc13e4ec29ea75e483e145890; } ?>
<?php $__attrs9f7e6fbbc13e4ec29ea75e483e145890 = []; ?>
<?php $__slots9f7e6fbbc13e4ec29ea75e483e145890 = []; ?>
<?php $__blaze->pushData($__attrs9f7e6fbbc13e4ec29ea75e483e145890); ?>
<?php ob_start(); ?><?php echo e($description); ?><?php $__slots9f7e6fbbc13e4ec29ea75e483e145890['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots9f7e6fbbc13e4ec29ea75e483e145890); ?>
<?php __9f7e6fbbc13e4ec29ea75e483e145890($__blaze, $__attrs9f7e6fbbc13e4ec29ea75e483e145890, $__slots9f7e6fbbc13e4ec29ea75e483e145890, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9f7e6fbbc13e4ec29ea75e483e145890)) { $__slots9f7e6fbbc13e4ec29ea75e483e145890 = array_pop($__slotsStack9f7e6fbbc13e4ec29ea75e483e145890); } ?>
<?php if (! empty($__attrsStack9f7e6fbbc13e4ec29ea75e483e145890)) { $__attrs9f7e6fbbc13e4ec29ea75e483e145890 = array_pop($__attrsStack9f7e6fbbc13e4ec29ea75e483e145890); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        [STARTCOMPILEDUNBLAZE:OfKV3aa0x0]<?php \Livewire\Blaze\Unblaze::storeScope("OfKV3aa0x0", scope: ['name' => $name]) ?><?php \Livewire\Blaze\Unblaze::storeReplacement("OfKV3aa0x0", "CiAgICAgICAgICAgIDxmbHV4OmVycm9yIDpuYW1lPSIkc2NvcGVbJ25hbWUnXSIgLz4KICAgICAgICA=") ?>[ENDCOMPILEDUNBLAZE:OfKV3aa0x0]
    <?php $__slots0987649927eebf2ef59dcf0475420130['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots0987649927eebf2ef59dcf0475420130); ?>
<?php __0987649927eebf2ef59dcf0475420130($__blaze, $__attrs0987649927eebf2ef59dcf0475420130, $__slots0987649927eebf2ef59dcf0475420130, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack0987649927eebf2ef59dcf0475420130)) { $__slots0987649927eebf2ef59dcf0475420130 = array_pop($__slotsStack0987649927eebf2ef59dcf0475420130); } ?>
<?php if (! empty($__attrsStack0987649927eebf2ef59dcf0475420130)) { $__attrs0987649927eebf2ef59dcf0475420130 = array_pop($__attrsStack0987649927eebf2ef59dcf0475420130); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>

<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/with-inline-field.blade.php ENDPATH**/ ?>
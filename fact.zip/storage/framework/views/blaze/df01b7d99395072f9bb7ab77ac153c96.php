<?php
if (!function_exists('__df01b7d99395072f9bb7ab77ac153c96')):
function __df01b7d99395072f9bb7ab77ac153c96($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'iconVariant' => 'mini',
    'size' => null,
];
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$size ??= $attributes['size'] ?? $__defaults['size']; unset($attributes['size']);
unset($__defaults);
?>

<?php
$attributes = $attributes->merge([
    'variant' => 'subtle',
    'class' => '-me-1 [[data-flux-input]:has(input:placeholder-shown)_&]:hidden [[data-flux-input]:has(input[disabled])_&]:hidden',
    'square' => true,
    'size' => null,
]);
?>

<?php if (!function_exists('__e1da437d716e1318981ce19c7bc0deeb')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/e1da437d716e1318981ce19c7bc0deeb.php'); require $__blaze->compiledPath.'/e1da437d716e1318981ce19c7bc0deeb.php'; } ?>
<?php if (isset($__slotse1da437d716e1318981ce19c7bc0deeb)) { $__slotsStacke1da437d716e1318981ce19c7bc0deeb[] = $__slotse1da437d716e1318981ce19c7bc0deeb; } ?>
<?php if (isset($__attrse1da437d716e1318981ce19c7bc0deeb)) { $__attrsStacke1da437d716e1318981ce19c7bc0deeb[] = $__attrse1da437d716e1318981ce19c7bc0deeb; } ?>
<?php $__attrse1da437d716e1318981ce19c7bc0deeb = ['attributes' => $attributes,'size' => $size === 'sm' || $size === 'xs' ? 'xs' : 'sm','xData' => 'fluxInputClearable','xOn:click' => 'clear()','tabindex' => '-1','ariaLabel' => e(__('Clear input')),'dataFluxClearButton' => true]; ?>
<?php $__slotse1da437d716e1318981ce19c7bc0deeb = []; ?>
<?php $__blaze->pushData($__attrse1da437d716e1318981ce19c7bc0deeb); ?>
<?php ob_start(); ?>
    <?php if (!function_exists('__514e9ea42b0658264b02ccd43424eca1')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/x-mark.blade.php', $__blaze->compiledPath.'/514e9ea42b0658264b02ccd43424eca1.php'); require $__blaze->compiledPath.'/514e9ea42b0658264b02ccd43424eca1.php'; } ?>
<?php $__blaze->pushData(['variant' => $iconVariant]); ?>
<?php __514e9ea42b0658264b02ccd43424eca1($__blaze, ['variant' => $iconVariant], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
<?php $__slotse1da437d716e1318981ce19c7bc0deeb['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotse1da437d716e1318981ce19c7bc0deeb); ?>
<?php __e1da437d716e1318981ce19c7bc0deeb($__blaze, $__attrse1da437d716e1318981ce19c7bc0deeb, $__slotse1da437d716e1318981ce19c7bc0deeb, ['attributes', 'size', 'dataFluxClearButton'], ['xData' => 'x-data', 'xOn:click' => 'x-on:click', 'ariaLabel' => 'aria-label', 'dataFluxClearButton' => 'data-flux-clear-button'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke1da437d716e1318981ce19c7bc0deeb)) { $__slotse1da437d716e1318981ce19c7bc0deeb = array_pop($__slotsStacke1da437d716e1318981ce19c7bc0deeb); } ?>
<?php if (! empty($__attrsStacke1da437d716e1318981ce19c7bc0deeb)) { $__attrse1da437d716e1318981ce19c7bc0deeb = array_pop($__attrsStacke1da437d716e1318981ce19c7bc0deeb); } ?>
<?php $__blaze->popData(); ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/input/clearable.blade.php ENDPATH**/ ?>
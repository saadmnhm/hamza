<?php
if (!function_exists('__b2112e3c8ee8916fa83dece5e302b9c3')):
function __b2112e3c8ee8916fa83dece5e302b9c3($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'tooltipPosition',
    'tooltipKbd',
    'tooltip',
]));
?>

<?php $tooltipPosition = $tooltipPosition ??= $attributes->pluck('tooltip:position'); ?>
<?php $tooltipKbd = $tooltipKbd ??= $attributes->pluck('tooltip:kbd'); ?>
<?php $tooltip = $tooltip ??= $attributes->pluck('tooltip'); ?>

<?php
$__defaults = [
    'tooltipPosition' => 'top',
    'tooltipKbd' => null,
    'tooltip' => null,
];
$tooltipPosition ??= $attributes['tooltip-position'] ?? $attributes['tooltipPosition'] ?? $__defaults['tooltipPosition']; unset($attributes['tooltipPosition'], $attributes['tooltip-position']);
$tooltipKbd ??= $attributes['tooltip-kbd'] ?? $attributes['tooltipKbd'] ?? $__defaults['tooltipKbd']; unset($attributes['tooltipKbd'], $attributes['tooltip-kbd']);
$tooltip ??= $attributes['tooltip'] ?? $__defaults['tooltip']; unset($attributes['tooltip']);
unset($__defaults);
?>

<?php if ($tooltip): ?>
    <?php if (!function_exists('__ac410b79ba3d50b8945b218f9d70a7ea')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php', $__blaze->compiledPath.'/ac410b79ba3d50b8945b218f9d70a7ea.php'); require $__blaze->compiledPath.'/ac410b79ba3d50b8945b218f9d70a7ea.php'; } ?>
<?php if (isset($__slotsac410b79ba3d50b8945b218f9d70a7ea)) { $__slotsStackac410b79ba3d50b8945b218f9d70a7ea[] = $__slotsac410b79ba3d50b8945b218f9d70a7ea; } ?>
<?php if (isset($__attrsac410b79ba3d50b8945b218f9d70a7ea)) { $__attrsStackac410b79ba3d50b8945b218f9d70a7ea[] = $__attrsac410b79ba3d50b8945b218f9d70a7ea; } ?>
<?php $__attrsac410b79ba3d50b8945b218f9d70a7ea = ['class' => 'inline-flex','content' => $tooltip,'position' => $tooltipPosition,'kbd' => $tooltipKbd]; ?>
<?php $__slotsac410b79ba3d50b8945b218f9d70a7ea = []; ?>
<?php $__blaze->pushData($__attrsac410b79ba3d50b8945b218f9d70a7ea); ?>
<?php ob_start(); ?>
        <?php echo e($slot); ?>

    <?php $__slotsac410b79ba3d50b8945b218f9d70a7ea['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsac410b79ba3d50b8945b218f9d70a7ea); ?>
<?php __ac410b79ba3d50b8945b218f9d70a7ea($__blaze, $__attrsac410b79ba3d50b8945b218f9d70a7ea, $__slotsac410b79ba3d50b8945b218f9d70a7ea, ['content', 'position', 'kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackac410b79ba3d50b8945b218f9d70a7ea)) { $__slotsac410b79ba3d50b8945b218f9d70a7ea = array_pop($__slotsStackac410b79ba3d50b8945b218f9d70a7ea); } ?>
<?php if (! empty($__attrsStackac410b79ba3d50b8945b218f9d70a7ea)) { $__attrsac410b79ba3d50b8945b218f9d70a7ea = array_pop($__attrsStackac410b79ba3d50b8945b218f9d70a7ea); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/with-tooltip.blade.php ENDPATH**/ ?>
<?php
if (!function_exists('__641eaa7fff7c43d0fb94f61f7cdba439')):
function __641eaa7fff7c43d0fb94f61f7cdba439($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'name',
    'descriptionTrailing',
    'description',
    'label',
    'badge',
]));
?>

<?php $descriptionTrailing = $descriptionTrailing ??= $attributes->pluck('description:trailing'); ?>

<?php
$__defaults = [
    'name' => $attributes->whereStartsWith('wire:model')->first(),
    'descriptionTrailing' => null,
    'description' => null,
    'label' => null,
    'badge' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
$descriptionTrailing ??= $attributes['description-trailing'] ?? $attributes['descriptionTrailing'] ?? $__defaults['descriptionTrailing']; unset($attributes['descriptionTrailing'], $attributes['description-trailing']);
$description ??= $attributes['description'] ?? $__defaults['description']; unset($attributes['description']);
$label ??= $attributes['label'] ?? $__defaults['label']; unset($attributes['label']);
$badge ??= $attributes['badge'] ?? $__defaults['badge']; unset($attributes['badge']);
unset($__defaults);
?>

<?php if (isset($label) || isset($description) || isset($descriptionTrailing)): ?>
    <?php

        $fieldAttributes = Flux::attributesAfter('field:', $attributes, []);
        $labelAttributes = Flux::attributesAfter('label:', $attributes, ['badge' => $badge]);
        $descriptionAttributes = Flux::attributesAfter('description:', $attributes, []);
        $errorAttributes = Flux::attributesAfter('error:', $attributes, ['name' => $name]);
    ?>
    <?php if (!function_exists('__0987649927eebf2ef59dcf0475420130')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php', $__blaze->compiledPath.'/0987649927eebf2ef59dcf0475420130.php'); require $__blaze->compiledPath.'/0987649927eebf2ef59dcf0475420130.php'; } ?>
<?php if (isset($__slots0987649927eebf2ef59dcf0475420130)) { $__slotsStack0987649927eebf2ef59dcf0475420130[] = $__slots0987649927eebf2ef59dcf0475420130; } ?>
<?php if (isset($__attrs0987649927eebf2ef59dcf0475420130)) { $__attrsStack0987649927eebf2ef59dcf0475420130[] = $__attrs0987649927eebf2ef59dcf0475420130; } ?>
<?php $__attrs0987649927eebf2ef59dcf0475420130 = ['attributes' => $fieldAttributes]; ?>
<?php $__slots0987649927eebf2ef59dcf0475420130 = []; ?>
<?php $__blaze->pushData($__attrs0987649927eebf2ef59dcf0475420130); ?>
<?php ob_start(); ?>
        <?php if (isset($label)): ?>
            <?php if (!function_exists('__9017229a7ef12f992d2ffffd18157a3b')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php', $__blaze->compiledPath.'/9017229a7ef12f992d2ffffd18157a3b.php'); require $__blaze->compiledPath.'/9017229a7ef12f992d2ffffd18157a3b.php'; } ?>
<?php if (isset($__slots9017229a7ef12f992d2ffffd18157a3b)) { $__slotsStack9017229a7ef12f992d2ffffd18157a3b[] = $__slots9017229a7ef12f992d2ffffd18157a3b; } ?>
<?php if (isset($__attrs9017229a7ef12f992d2ffffd18157a3b)) { $__attrsStack9017229a7ef12f992d2ffffd18157a3b[] = $__attrs9017229a7ef12f992d2ffffd18157a3b; } ?>
<?php $__attrs9017229a7ef12f992d2ffffd18157a3b = ['attributes' => $labelAttributes]; ?>
<?php $__slots9017229a7ef12f992d2ffffd18157a3b = []; ?>
<?php $__blaze->pushData($__attrs9017229a7ef12f992d2ffffd18157a3b); ?>
<?php ob_start(); ?><?php echo e($label); ?><?php $__slots9017229a7ef12f992d2ffffd18157a3b['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots9017229a7ef12f992d2ffffd18157a3b); ?>
<?php __9017229a7ef12f992d2ffffd18157a3b($__blaze, $__attrs9017229a7ef12f992d2ffffd18157a3b, $__slots9017229a7ef12f992d2ffffd18157a3b, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9017229a7ef12f992d2ffffd18157a3b)) { $__slots9017229a7ef12f992d2ffffd18157a3b = array_pop($__slotsStack9017229a7ef12f992d2ffffd18157a3b); } ?>
<?php if (! empty($__attrsStack9017229a7ef12f992d2ffffd18157a3b)) { $__attrs9017229a7ef12f992d2ffffd18157a3b = array_pop($__attrsStack9017229a7ef12f992d2ffffd18157a3b); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php if (isset($description)): ?>
            <?php if (!function_exists('__9f7e6fbbc13e4ec29ea75e483e145890')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/9f7e6fbbc13e4ec29ea75e483e145890.php'); require $__blaze->compiledPath.'/9f7e6fbbc13e4ec29ea75e483e145890.php'; } ?>
<?php if (isset($__slots9f7e6fbbc13e4ec29ea75e483e145890)) { $__slotsStack9f7e6fbbc13e4ec29ea75e483e145890[] = $__slots9f7e6fbbc13e4ec29ea75e483e145890; } ?>
<?php if (isset($__attrs9f7e6fbbc13e4ec29ea75e483e145890)) { $__attrsStack9f7e6fbbc13e4ec29ea75e483e145890[] = $__attrs9f7e6fbbc13e4ec29ea75e483e145890; } ?>
<?php $__attrs9f7e6fbbc13e4ec29ea75e483e145890 = ['attributes' => $descriptionAttributes]; ?>
<?php $__slots9f7e6fbbc13e4ec29ea75e483e145890 = []; ?>
<?php $__blaze->pushData($__attrs9f7e6fbbc13e4ec29ea75e483e145890); ?>
<?php ob_start(); ?><?php echo e($description); ?><?php $__slots9f7e6fbbc13e4ec29ea75e483e145890['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots9f7e6fbbc13e4ec29ea75e483e145890); ?>
<?php __9f7e6fbbc13e4ec29ea75e483e145890($__blaze, $__attrs9f7e6fbbc13e4ec29ea75e483e145890, $__slots9f7e6fbbc13e4ec29ea75e483e145890, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9f7e6fbbc13e4ec29ea75e483e145890)) { $__slots9f7e6fbbc13e4ec29ea75e483e145890 = array_pop($__slotsStack9f7e6fbbc13e4ec29ea75e483e145890); } ?>
<?php if (! empty($__attrsStack9f7e6fbbc13e4ec29ea75e483e145890)) { $__attrs9f7e6fbbc13e4ec29ea75e483e145890 = array_pop($__attrsStack9f7e6fbbc13e4ec29ea75e483e145890); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php echo e($slot); ?>


        
        [STARTCOMPILEDUNBLAZE:tJahrjGAWH]<?php \Livewire\Blaze\Unblaze::storeScope("tJahrjGAWH", scope: ['attributes' => $errorAttributes->getAttributes()]) ?><?php \Livewire\Blaze\Unblaze::storeReplacement("tJahrjGAWH", "CiAgICAgICAgPGZsdXg6ZXJyb3IgOmF0dHJpYnV0ZXM9Im5ldyBcSWxsdW1pbmF0ZVxWaWV3XENvbXBvbmVudEF0dHJpYnV0ZUJhZygkc2NvcGVbJ2F0dHJpYnV0ZXMnXSkiIC8+CiAgICAgICAg") ?>[ENDCOMPILEDUNBLAZE:tJahrjGAWH]

        <?php if (isset($descriptionTrailing)): ?>
            <?php if (!function_exists('__9f7e6fbbc13e4ec29ea75e483e145890')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/9f7e6fbbc13e4ec29ea75e483e145890.php'); require $__blaze->compiledPath.'/9f7e6fbbc13e4ec29ea75e483e145890.php'; } ?>
<?php if (isset($__slots9f7e6fbbc13e4ec29ea75e483e145890)) { $__slotsStack9f7e6fbbc13e4ec29ea75e483e145890[] = $__slots9f7e6fbbc13e4ec29ea75e483e145890; } ?>
<?php if (isset($__attrs9f7e6fbbc13e4ec29ea75e483e145890)) { $__attrsStack9f7e6fbbc13e4ec29ea75e483e145890[] = $__attrs9f7e6fbbc13e4ec29ea75e483e145890; } ?>
<?php $__attrs9f7e6fbbc13e4ec29ea75e483e145890 = ['attributes' => $descriptionAttributes]; ?>
<?php $__slots9f7e6fbbc13e4ec29ea75e483e145890 = []; ?>
<?php $__blaze->pushData($__attrs9f7e6fbbc13e4ec29ea75e483e145890); ?>
<?php ob_start(); ?><?php echo e($descriptionTrailing); ?><?php $__slots9f7e6fbbc13e4ec29ea75e483e145890['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots9f7e6fbbc13e4ec29ea75e483e145890); ?>
<?php __9f7e6fbbc13e4ec29ea75e483e145890($__blaze, $__attrs9f7e6fbbc13e4ec29ea75e483e145890, $__slots9f7e6fbbc13e4ec29ea75e483e145890, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9f7e6fbbc13e4ec29ea75e483e145890)) { $__slots9f7e6fbbc13e4ec29ea75e483e145890 = array_pop($__slotsStack9f7e6fbbc13e4ec29ea75e483e145890); } ?>
<?php if (! empty($__attrsStack9f7e6fbbc13e4ec29ea75e483e145890)) { $__attrs9f7e6fbbc13e4ec29ea75e483e145890 = array_pop($__attrsStack9f7e6fbbc13e4ec29ea75e483e145890); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    <?php $__slots0987649927eebf2ef59dcf0475420130['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots0987649927eebf2ef59dcf0475420130); ?>
<?php __0987649927eebf2ef59dcf0475420130($__blaze, $__attrs0987649927eebf2ef59dcf0475420130, $__slots0987649927eebf2ef59dcf0475420130, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack0987649927eebf2ef59dcf0475420130)) { $__slots0987649927eebf2ef59dcf0475420130 = array_pop($__slotsStack0987649927eebf2ef59dcf0475420130); } ?>
<?php if (! empty($__attrsStack0987649927eebf2ef59dcf0475420130)) { $__attrs0987649927eebf2ef59dcf0475420130 = array_pop($__attrsStack0987649927eebf2ef59dcf0475420130); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/with-field.blade.php ENDPATH**/ ?>
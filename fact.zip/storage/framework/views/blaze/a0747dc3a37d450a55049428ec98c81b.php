<?php
if (!function_exists('__a0747dc3a37d450a55049428ec98c81b')):
function __a0747dc3a37d450a55049428ec98c81b($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'direction' => null,
    'sorted' => false,
];
$direction ??= $attributes['direction'] ?? $__defaults['direction']; unset($attributes['direction']);
$sorted ??= $attributes['sorted'] ?? $__defaults['sorted']; unset($attributes['sorted']);
unset($__defaults);
?>

<?php
$classes = Flux::classes()
    ->add('flex items-center gap-1 -my-1 -ms-2 -me-2 px-2 py-1')
    ->add('[text-align:inherit] [text-indent:inherit] [text-shadow:inherit] [text-transform:inherit] [word-spacing:inherit]')
    ->add('in-[.group\/end-align]:flex-row-reverse in-[.group\/end-align]:-me-2 in-[.group\/end-align]:-ms-8')
    ;
?>

<button type="button" <?php echo e($attributes->class($classes)); ?> data-flux-table-sortable>
    <?php echo e($slot); ?>


    <div class="rounded-sm text-zinc-400 group-hover/sortable:text-zinc-800 dark:group-hover/sortable:text-white">
        <?php if ($sorted): ?>
            <?php if ($direction === 'asc'): ?>
                <?php if (!function_exists('__b36d1f1148c40d8a30e7b4368a80b410')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-up.blade.php', $__blaze->compiledPath.'/b36d1f1148c40d8a30e7b4368a80b410.php'); require $__blaze->compiledPath.'/b36d1f1148c40d8a30e7b4368a80b410.php'; } ?>
<?php $__blaze->pushData(['variant' => 'micro']); ?>
<?php __b36d1f1148c40d8a30e7b4368a80b410($__blaze, ['variant' => 'micro'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            <?php elseif ($direction === 'desc'): ?>
                <?php if (!function_exists('__68cdc6e8f743092f1e1adce792b7ce43')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-down.blade.php', $__blaze->compiledPath.'/68cdc6e8f743092f1e1adce792b7ce43.php'); require $__blaze->compiledPath.'/68cdc6e8f743092f1e1adce792b7ce43.php'; } ?>
<?php $__blaze->pushData(['variant' => 'micro']); ?>
<?php __68cdc6e8f743092f1e1adce792b7ce43($__blaze, ['variant' => 'micro'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            <?php else: ?>
                <?php if (!function_exists('__68cdc6e8f743092f1e1adce792b7ce43')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-down.blade.php', $__blaze->compiledPath.'/68cdc6e8f743092f1e1adce792b7ce43.php'); require $__blaze->compiledPath.'/68cdc6e8f743092f1e1adce792b7ce43.php'; } ?>
<?php $__blaze->pushData(['variant' => 'micro']); ?>
<?php __68cdc6e8f743092f1e1adce792b7ce43($__blaze, ['variant' => 'micro'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            <?php endif; ?>
        <?php else: ?>
            <div class="opacity-0 group-hover/sortable:opacity-100">
                <?php if (!function_exists('__68cdc6e8f743092f1e1adce792b7ce43')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-down.blade.php', $__blaze->compiledPath.'/68cdc6e8f743092f1e1adce792b7ce43.php'); require $__blaze->compiledPath.'/68cdc6e8f743092f1e1adce792b7ce43.php'; } ?>
<?php $__blaze->pushData(['variant' => 'micro']); ?>
<?php __68cdc6e8f743092f1e1adce792b7ce43($__blaze, ['variant' => 'micro'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            </div>
        <?php endif; ?>
    </div>
</button>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/table/sortable.blade.php ENDPATH**/ ?>
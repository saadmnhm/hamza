<?php
if (!function_exists('__cc583f9b99f16bfbe84137570ef4b1ca')):
function __cc583f9b99f16bfbe84137570ef4b1ca($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php $iconTrailing ??= $attributes->pluck('icon:trailing'); ?>
<?php $iconVariant ??= $attributes->pluck('icon:variant'); ?>

<?php
$__defaults = [
    'iconVariant' => 'outline',
    'iconTrailing' => null,
    'expandable' => false,
    'expanded' => true,
    'heading' => null,
    'icon' => null,
];
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$iconTrailing ??= $attributes['icon-trailing'] ?? $attributes['iconTrailing'] ?? $__defaults['iconTrailing']; unset($attributes['iconTrailing'], $attributes['icon-trailing']);
$expandable ??= $attributes['expandable'] ?? $__defaults['expandable']; unset($attributes['expandable']);
$expanded ??= $attributes['expanded'] ?? $__defaults['expanded']; unset($attributes['expanded']);
$heading ??= $attributes['heading'] ?? $__defaults['heading']; unset($attributes['heading']);
$icon ??= $attributes['icon'] ?? $__defaults['icon']; unset($attributes['icon']);
unset($__defaults);
?>

<?php if ($expandable && $heading): ?>
    <?php if ($icon): ?>
        <ui-disclosure <?php echo e($attributes->class('group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden')); ?> <?php if($expanded === true): ?> open <?php endif; ?> data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="px-3">
                    <?php if (is_string($icon) && $icon !== ''): ?>
                        <?php if (!function_exists('__b818240420d205fb85c457a5f0251124')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/b818240420d205fb85c457a5f0251124.php'); require $__blaze->compiledPath.'/b818240420d205fb85c457a5f0251124.php'; } ?>
<?php $__blaze->pushData(['icon' => $icon,'variant' => $iconVariant,'class' => 'size-4']); ?>
<?php __b818240420d205fb85c457a5f0251124($__blaze, ['icon' => $icon,'variant' => $iconVariant,'class' => 'size-4'], [], ['icon', 'variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    <?php else: ?>
                        <?php echo e($icon); ?>

                    <?php endif; ?>
                </div>

                <span class="flex-1 text-left rtl:text-right text-sm font-medium truncate"><?php echo e($heading); ?></span>

                <div class="ps-3 pe-2.5">
                    <?php if (!function_exists('__68cdc6e8f743092f1e1adce792b7ce43')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-down.blade.php', $__blaze->compiledPath.'/68cdc6e8f743092f1e1adce792b7ce43.php'); require $__blaze->compiledPath.'/68cdc6e8f743092f1e1adce792b7ce43.php'; } ?>
<?php $__blaze->pushData(['class' => 'size-3! hidden group-data-open/disclosure-button:block']); ?>
<?php __68cdc6e8f743092f1e1adce792b7ce43($__blaze, ['class' => 'size-3! hidden group-data-open/disclosure-button:block'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    <?php if (!function_exists('__6adb45cece6f320f07bd5ed0705b4aa5')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-right.blade.php', $__blaze->compiledPath.'/6adb45cece6f320f07bd5ed0705b4aa5.php'); require $__blaze->compiledPath.'/6adb45cece6f320f07bd5ed0705b4aa5.php'; } ?>
<?php $__blaze->pushData(['class' => 'size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180']); ?>
<?php __6adb45cece6f320f07bd5ed0705b4aa5($__blaze, ['class' => 'size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                </div>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" <?php if($expanded === true): ?> data-open <?php endif; ?>>
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php echo e($slot); ?>

                </div>
            </div>
        </ui-disclosure>

        <?php if (!function_exists('__914e4aaa91df5b31cd7c1888e16af933')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/dropdown.blade.php', $__blaze->compiledPath.'/914e4aaa91df5b31cd7c1888e16af933.php'); require $__blaze->compiledPath.'/914e4aaa91df5b31cd7c1888e16af933.php'; } ?>
<?php if (isset($__slots914e4aaa91df5b31cd7c1888e16af933)) { $__slotsStack914e4aaa91df5b31cd7c1888e16af933[] = $__slots914e4aaa91df5b31cd7c1888e16af933; } ?>
<?php if (isset($__attrs914e4aaa91df5b31cd7c1888e16af933)) { $__attrsStack914e4aaa91df5b31cd7c1888e16af933[] = $__attrs914e4aaa91df5b31cd7c1888e16af933; } ?>
<?php $__attrs914e4aaa91df5b31cd7c1888e16af933 = ['hover' => true,'class' => 'in-data-flux-sidebar-on-mobile:hidden not-in-data-flux-sidebar-collapsed-desktop:hidden','position' => 'right','align' => 'start','dataFluxSidebarGroupDropdown' => true]; ?>
<?php $__slots914e4aaa91df5b31cd7c1888e16af933 = []; ?>
<?php $__blaze->pushData($__attrs914e4aaa91df5b31cd7c1888e16af933); ?>
<?php ob_start(); ?>
            <button type="button" class="border-1 border-transparent w-full px-3 in-data-flux-menu:px-2 h-8 flex gap-3 items-center group/disclosure-button my-px rounded-lg in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-menu:w-10 in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-menu:justify-center hover:bg-zinc-800/5 dark:hover:bg-white/[7%] in-data-flux-menu:hover:bg-zinc-50 dark:in-data-flux-menu:hover:bg-zinc-600 text-zinc-500 in-data-flux-menu:text-zinc-800 hover:text-zinc-800 dark:text-white/80 in-data-flux-menu:dark:text-white dark:hover:text-white">
                <?php if ($icon): ?>
                    <div class="relative">
                        <?php if (is_string($icon) && $icon !== ''): ?>
                            <?php if (!function_exists('__b818240420d205fb85c457a5f0251124')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/b818240420d205fb85c457a5f0251124.php'); require $__blaze->compiledPath.'/b818240420d205fb85c457a5f0251124.php'; } ?>
<?php $__blaze->pushData(['icon' => $icon,'variant' => $iconVariant,'class' => 'in-data-flux-menu:text-zinc-400 in-data-flux-menu:dark:text-white/80 in-data-flux-menu:[[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current size-4']); ?>
<?php __b818240420d205fb85c457a5f0251124($__blaze, ['icon' => $icon,'variant' => $iconVariant,'class' => 'in-data-flux-menu:text-zinc-400 in-data-flux-menu:dark:text-white/80 in-data-flux-menu:[[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current size-4'], [], ['icon', 'variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                        <?php else: ?>
                            <?php echo e($icon); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <span class="hidden in-data-flux-menu:block flex-1 text-start text-sm font-medium leading-none text-zinc-800 dark:text-white"><?php echo e($heading); ?></span>

                <div class="hidden in-data-flux-menu:block">
                    <?php if (!function_exists('__6adb45cece6f320f07bd5ed0705b4aa5')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-right.blade.php', $__blaze->compiledPath.'/6adb45cece6f320f07bd5ed0705b4aa5.php'); require $__blaze->compiledPath.'/6adb45cece6f320f07bd5ed0705b4aa5.php'; } ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'ms-auto size-4 text-zinc-400 [[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current rtl:hidden']); ?>
<?php __6adb45cece6f320f07bd5ed0705b4aa5($__blaze, ['variant' => $iconVariant,'class' => 'ms-auto size-4 text-zinc-400 [[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current rtl:hidden'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    <?php if (!function_exists('__6cfbb9d94d49c567fa4baa7bc78ffea6')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-left.blade.php', $__blaze->compiledPath.'/6cfbb9d94d49c567fa4baa7bc78ffea6.php'); require $__blaze->compiledPath.'/6cfbb9d94d49c567fa4baa7bc78ffea6.php'; } ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'ms-auto size-4 text-zinc-400 [[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current hidden rtl:inline']); ?>
<?php __6cfbb9d94d49c567fa4baa7bc78ffea6($__blaze, ['variant' => $iconVariant,'class' => 'ms-auto size-4 text-zinc-400 [[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current hidden rtl:inline'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                </div>
            </button>

            <?php if (!function_exists('__ba575c7a4d5be7cd3dccce11f92a6df4')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/index.blade.php', $__blaze->compiledPath.'/ba575c7a4d5be7cd3dccce11f92a6df4.php'); require $__blaze->compiledPath.'/ba575c7a4d5be7cd3dccce11f92a6df4.php'; } ?>
<?php if (isset($__slotsba575c7a4d5be7cd3dccce11f92a6df4)) { $__slotsStackba575c7a4d5be7cd3dccce11f92a6df4[] = $__slotsba575c7a4d5be7cd3dccce11f92a6df4; } ?>
<?php if (isset($__attrsba575c7a4d5be7cd3dccce11f92a6df4)) { $__attrsStackba575c7a4d5be7cd3dccce11f92a6df4[] = $__attrsba575c7a4d5be7cd3dccce11f92a6df4; } ?>
<?php $__attrsba575c7a4d5be7cd3dccce11f92a6df4 = []; ?>
<?php $__slotsba575c7a4d5be7cd3dccce11f92a6df4 = []; ?>
<?php $__blaze->pushData($__attrsba575c7a4d5be7cd3dccce11f92a6df4); ?>
<?php ob_start(); ?>
                <?php if (!function_exists('__160fc1ba88780ffc9cb9a04ccddcc42f')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/group.blade.php', $__blaze->compiledPath.'/160fc1ba88780ffc9cb9a04ccddcc42f.php'); require $__blaze->compiledPath.'/160fc1ba88780ffc9cb9a04ccddcc42f.php'; } ?>
<?php if (isset($__slots160fc1ba88780ffc9cb9a04ccddcc42f)) { $__slotsStack160fc1ba88780ffc9cb9a04ccddcc42f[] = $__slots160fc1ba88780ffc9cb9a04ccddcc42f; } ?>
<?php if (isset($__attrs160fc1ba88780ffc9cb9a04ccddcc42f)) { $__attrsStack160fc1ba88780ffc9cb9a04ccddcc42f[] = $__attrs160fc1ba88780ffc9cb9a04ccddcc42f; } ?>
<?php $__attrs160fc1ba88780ffc9cb9a04ccddcc42f = ['heading' => $heading]; ?>
<?php $__slots160fc1ba88780ffc9cb9a04ccddcc42f = []; ?>
<?php $__blaze->pushData($__attrs160fc1ba88780ffc9cb9a04ccddcc42f); ?>
<?php ob_start(); ?>
                    <?php echo e($slot); ?>

                <?php $__slots160fc1ba88780ffc9cb9a04ccddcc42f['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots160fc1ba88780ffc9cb9a04ccddcc42f); ?>
<?php __160fc1ba88780ffc9cb9a04ccddcc42f($__blaze, $__attrs160fc1ba88780ffc9cb9a04ccddcc42f, $__slots160fc1ba88780ffc9cb9a04ccddcc42f, ['heading'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack160fc1ba88780ffc9cb9a04ccddcc42f)) { $__slots160fc1ba88780ffc9cb9a04ccddcc42f = array_pop($__slotsStack160fc1ba88780ffc9cb9a04ccddcc42f); } ?>
<?php if (! empty($__attrsStack160fc1ba88780ffc9cb9a04ccddcc42f)) { $__attrs160fc1ba88780ffc9cb9a04ccddcc42f = array_pop($__attrsStack160fc1ba88780ffc9cb9a04ccddcc42f); } ?>
<?php $__blaze->popData(); ?>
            <?php $__slotsba575c7a4d5be7cd3dccce11f92a6df4['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsba575c7a4d5be7cd3dccce11f92a6df4); ?>
<?php __ba575c7a4d5be7cd3dccce11f92a6df4($__blaze, $__attrsba575c7a4d5be7cd3dccce11f92a6df4, $__slotsba575c7a4d5be7cd3dccce11f92a6df4, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackba575c7a4d5be7cd3dccce11f92a6df4)) { $__slotsba575c7a4d5be7cd3dccce11f92a6df4 = array_pop($__slotsStackba575c7a4d5be7cd3dccce11f92a6df4); } ?>
<?php if (! empty($__attrsStackba575c7a4d5be7cd3dccce11f92a6df4)) { $__attrsba575c7a4d5be7cd3dccce11f92a6df4 = array_pop($__attrsStackba575c7a4d5be7cd3dccce11f92a6df4); } ?>
<?php $__blaze->popData(); ?>
        <?php $__slots914e4aaa91df5b31cd7c1888e16af933['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots914e4aaa91df5b31cd7c1888e16af933); ?>
<?php __914e4aaa91df5b31cd7c1888e16af933($__blaze, $__attrs914e4aaa91df5b31cd7c1888e16af933, $__slots914e4aaa91df5b31cd7c1888e16af933, ['hover', 'dataFluxSidebarGroupDropdown'], ['dataFluxSidebarGroupDropdown' => 'data-flux-sidebar-group-dropdown'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack914e4aaa91df5b31cd7c1888e16af933)) { $__slots914e4aaa91df5b31cd7c1888e16af933 = array_pop($__slotsStack914e4aaa91df5b31cd7c1888e16af933); } ?>
<?php if (! empty($__attrsStack914e4aaa91df5b31cd7c1888e16af933)) { $__attrs914e4aaa91df5b31cd7c1888e16af933 = array_pop($__attrsStack914e4aaa91df5b31cd7c1888e16af933); } ?>
<?php $__blaze->popData(); ?>
    <?php else: ?>
        <ui-disclosure <?php echo e($attributes->class('group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden')); ?> <?php if($expanded === true): ?> open <?php endif; ?> data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <?php if (!function_exists('__68cdc6e8f743092f1e1adce792b7ce43')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-down.blade.php', $__blaze->compiledPath.'/68cdc6e8f743092f1e1adce792b7ce43.php'); require $__blaze->compiledPath.'/68cdc6e8f743092f1e1adce792b7ce43.php'; } ?>
<?php $__blaze->pushData(['class' => 'size-3! hidden group-data-open/disclosure-button:block']); ?>
<?php __68cdc6e8f743092f1e1adce792b7ce43($__blaze, ['class' => 'size-3! hidden group-data-open/disclosure-button:block'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    <?php if (!function_exists('__6adb45cece6f320f07bd5ed0705b4aa5')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-right.blade.php', $__blaze->compiledPath.'/6adb45cece6f320f07bd5ed0705b4aa5.php'); require $__blaze->compiledPath.'/6adb45cece6f320f07bd5ed0705b4aa5.php'; } ?>
<?php $__blaze->pushData(['class' => 'size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180']); ?>
<?php __6adb45cece6f320f07bd5ed0705b4aa5($__blaze, ['class' => 'size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                </div>

                <span class="text-sm font-medium truncate"><?php echo e($heading); ?></span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" <?php if($expanded === true): ?> data-open <?php endif; ?>>
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php echo e($slot); ?>

                </div>
            </div>
        </ui-disclosure>
    <?php endif; ?>

<?php elseif ($heading): ?>
    <div <?php echo e($attributes->class('flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden')); ?> data-flux-sidebar-group>
        <div class="px-3 py-2 text-sm text-zinc-400 font-medium leading-none truncate"><?php echo e($heading); ?></div>

        <div class="flex flex-col min-w-0">
            <?php echo e($slot); ?>

        </div>
    </div>
<?php else: ?>
    <div <?php echo e($attributes->class('flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden')); ?> data-flux-sidebar-group>
        <?php echo e($slot); ?>

    </div>
<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'sidebar' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'sidebar' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sidebar): ?>
    <?php if (!function_exists('_a0cb9a4e226f8afcd08a6e90a6c766af')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/brand.blade.php', $__blaze->compiledPath.'/a0cb9a4e226f8afcd08a6e90a6c766af.php'); require $__blaze->compiledPath.'/a0cb9a4e226f8afcd08a6e90a6c766af.php'; } ?>
<?php if (isset($__slotsa0cb9a4e226f8afcd08a6e90a6c766af)) { $__slotsStacka0cb9a4e226f8afcd08a6e90a6c766af[] = $__slotsa0cb9a4e226f8afcd08a6e90a6c766af; } ?>
<?php if (isset($__attrsa0cb9a4e226f8afcd08a6e90a6c766af)) { $__attrsStacka0cb9a4e226f8afcd08a6e90a6c766af[] = $__attrsa0cb9a4e226f8afcd08a6e90a6c766af; } ?>
<?php $__attrsa0cb9a4e226f8afcd08a6e90a6c766af = ['name' => config('app.name', 'Laravel'),'attributes' => $attributes]; ?>
<?php $__slotsa0cb9a4e226f8afcd08a6e90a6c766af = []; ?>
<?php $__blaze->pushData($__attrsa0cb9a4e226f8afcd08a6e90a6c766af); ?>
<?php ob_start(); ?>
         <?php ob_start(); ?>
            <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['class' => 'size-5 fill-current text-white dark:text-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 fill-current text-white dark:text-black']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
        <?php $__slotsa0cb9a4e226f8afcd08a6e90a6c766af['logo'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), ['class' => 'flex aspect-square size-8 items-center justify-center rounded-md bg-accent-content text-accent-foreground']); ?>
    <?php $__slotsa0cb9a4e226f8afcd08a6e90a6c766af['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsa0cb9a4e226f8afcd08a6e90a6c766af); ?>
<?php _a0cb9a4e226f8afcd08a6e90a6c766af($__blaze, $__attrsa0cb9a4e226f8afcd08a6e90a6c766af, $__slotsa0cb9a4e226f8afcd08a6e90a6c766af, ['name', 'attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacka0cb9a4e226f8afcd08a6e90a6c766af)) { $__slotsa0cb9a4e226f8afcd08a6e90a6c766af = array_pop($__slotsStacka0cb9a4e226f8afcd08a6e90a6c766af); } ?>
<?php if (! empty($__attrsStacka0cb9a4e226f8afcd08a6e90a6c766af)) { $__attrsa0cb9a4e226f8afcd08a6e90a6c766af = array_pop($__attrsStacka0cb9a4e226f8afcd08a6e90a6c766af); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php if (!function_exists('_430c4dabd5d61f51a4340e9b384b075e')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/brand.blade.php', $__blaze->compiledPath.'/430c4dabd5d61f51a4340e9b384b075e.php'); require $__blaze->compiledPath.'/430c4dabd5d61f51a4340e9b384b075e.php'; } ?>
<?php if (isset($__slots430c4dabd5d61f51a4340e9b384b075e)) { $__slotsStack430c4dabd5d61f51a4340e9b384b075e[] = $__slots430c4dabd5d61f51a4340e9b384b075e; } ?>
<?php if (isset($__attrs430c4dabd5d61f51a4340e9b384b075e)) { $__attrsStack430c4dabd5d61f51a4340e9b384b075e[] = $__attrs430c4dabd5d61f51a4340e9b384b075e; } ?>
<?php $__attrs430c4dabd5d61f51a4340e9b384b075e = ['name' => config('app.name', 'Laravel'),'attributes' => $attributes]; ?>
<?php $__slots430c4dabd5d61f51a4340e9b384b075e = []; ?>
<?php $__blaze->pushData($__attrs430c4dabd5d61f51a4340e9b384b075e); ?>
<?php ob_start(); ?>
         <?php ob_start(); ?>
            <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['class' => 'size-5 fill-current text-white dark:text-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 fill-current text-white dark:text-black']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
        <?php $__slots430c4dabd5d61f51a4340e9b384b075e['logo'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), ['class' => 'flex aspect-square size-8 items-center justify-center rounded-md bg-accent-content text-accent-foreground']); ?>
    <?php $__slots430c4dabd5d61f51a4340e9b384b075e['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots430c4dabd5d61f51a4340e9b384b075e); ?>
<?php _430c4dabd5d61f51a4340e9b384b075e($__blaze, $__attrs430c4dabd5d61f51a4340e9b384b075e, $__slots430c4dabd5d61f51a4340e9b384b075e, ['name', 'attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack430c4dabd5d61f51a4340e9b384b075e)) { $__slots430c4dabd5d61f51a4340e9b384b075e = array_pop($__slotsStack430c4dabd5d61f51a4340e9b384b075e); } ?>
<?php if (! empty($__attrsStack430c4dabd5d61f51a4340e9b384b075e)) { $__attrs430c4dabd5d61f51a4340e9b384b075e = array_pop($__attrsStack430c4dabd5d61f51a4340e9b384b075e); } ?>
<?php $__blaze->popData(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\xampp\htdocs\hamza\resources\views/components/app-logo.blade.php ENDPATH**/ ?>
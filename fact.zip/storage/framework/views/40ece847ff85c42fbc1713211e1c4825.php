<?php # [BlazeFolded]:{flux::navlist}:{C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/index.blade.php}:{1789478109} ?>
<?php # [BlazeFolded]:{flux::separator}:{C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/separator.blade.php}:{1789478109} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1789478109} ?>
<?php # [BlazeFolded]:{flux::subheading}:{C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1789478109} ?>
<div class="flex items-start max-md:flex-col">
    <div class="me-10 w-full pb-4 md:w-[220px]">
        <?php ob_start(); ?><?php $__blaze->pushData(['ariaLabel' => e(__('Settings'))]); $__env->pushConsumableComponentData(['ariaLabel' => e(__('Settings'))]); ?><nav class="flex flex-col overflow-visible min-h-auto" aria-label="<?php echo e(__('Settings')); ?>" data-flux-navlist>
    <?php ob_start(); ?>
            <?php if (!function_exists('_ffc832528375aae4305fa486cda07ac2')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/item.blade.php', $__blaze->compiledPath.'/ffc832528375aae4305fa486cda07ac2.php'); require $__blaze->compiledPath.'/ffc832528375aae4305fa486cda07ac2.php'; } ?>
<?php if (isset($__slotsffc832528375aae4305fa486cda07ac2)) { $__slotsStackffc832528375aae4305fa486cda07ac2[] = $__slotsffc832528375aae4305fa486cda07ac2; } ?>
<?php if (isset($__attrsffc832528375aae4305fa486cda07ac2)) { $__attrsStackffc832528375aae4305fa486cda07ac2[] = $__attrsffc832528375aae4305fa486cda07ac2; } ?>
<?php $__attrsffc832528375aae4305fa486cda07ac2 = ['href' => route('profile.edit'),'wire:navigate' => true]; ?>
<?php $__slotsffc832528375aae4305fa486cda07ac2 = []; ?>
<?php $__blaze->pushData($__attrsffc832528375aae4305fa486cda07ac2); ?>
<?php ob_start(); ?><?php echo e(__('Profile')); ?><?php $__slotsffc832528375aae4305fa486cda07ac2['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsffc832528375aae4305fa486cda07ac2); ?>
<?php _ffc832528375aae4305fa486cda07ac2($__blaze, $__attrsffc832528375aae4305fa486cda07ac2, $__slotsffc832528375aae4305fa486cda07ac2, ['href', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackffc832528375aae4305fa486cda07ac2)) { $__slotsffc832528375aae4305fa486cda07ac2 = array_pop($__slotsStackffc832528375aae4305fa486cda07ac2); } ?>
<?php if (! empty($__attrsStackffc832528375aae4305fa486cda07ac2)) { $__attrsffc832528375aae4305fa486cda07ac2 = array_pop($__attrsStackffc832528375aae4305fa486cda07ac2); } ?>
<?php $__blaze->popData(); ?>
            <?php if (!function_exists('_ffc832528375aae4305fa486cda07ac2')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/item.blade.php', $__blaze->compiledPath.'/ffc832528375aae4305fa486cda07ac2.php'); require $__blaze->compiledPath.'/ffc832528375aae4305fa486cda07ac2.php'; } ?>
<?php if (isset($__slotsffc832528375aae4305fa486cda07ac2)) { $__slotsStackffc832528375aae4305fa486cda07ac2[] = $__slotsffc832528375aae4305fa486cda07ac2; } ?>
<?php if (isset($__attrsffc832528375aae4305fa486cda07ac2)) { $__attrsStackffc832528375aae4305fa486cda07ac2[] = $__attrsffc832528375aae4305fa486cda07ac2; } ?>
<?php $__attrsffc832528375aae4305fa486cda07ac2 = ['href' => route('security.edit'),'wire:navigate' => true]; ?>
<?php $__slotsffc832528375aae4305fa486cda07ac2 = []; ?>
<?php $__blaze->pushData($__attrsffc832528375aae4305fa486cda07ac2); ?>
<?php ob_start(); ?><?php echo e(__('Security')); ?><?php $__slotsffc832528375aae4305fa486cda07ac2['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsffc832528375aae4305fa486cda07ac2); ?>
<?php _ffc832528375aae4305fa486cda07ac2($__blaze, $__attrsffc832528375aae4305fa486cda07ac2, $__slotsffc832528375aae4305fa486cda07ac2, ['href', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackffc832528375aae4305fa486cda07ac2)) { $__slotsffc832528375aae4305fa486cda07ac2 = array_pop($__slotsStackffc832528375aae4305fa486cda07ac2); } ?>
<?php if (! empty($__attrsStackffc832528375aae4305fa486cda07ac2)) { $__attrsffc832528375aae4305fa486cda07ac2 = array_pop($__attrsStackffc832528375aae4305fa486cda07ac2); } ?>
<?php $__blaze->popData(); ?>
            <?php if (!function_exists('_ffc832528375aae4305fa486cda07ac2')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/item.blade.php', $__blaze->compiledPath.'/ffc832528375aae4305fa486cda07ac2.php'); require $__blaze->compiledPath.'/ffc832528375aae4305fa486cda07ac2.php'; } ?>
<?php if (isset($__slotsffc832528375aae4305fa486cda07ac2)) { $__slotsStackffc832528375aae4305fa486cda07ac2[] = $__slotsffc832528375aae4305fa486cda07ac2; } ?>
<?php if (isset($__attrsffc832528375aae4305fa486cda07ac2)) { $__attrsStackffc832528375aae4305fa486cda07ac2[] = $__attrsffc832528375aae4305fa486cda07ac2; } ?>
<?php $__attrsffc832528375aae4305fa486cda07ac2 = ['href' => route('appearance.edit'),'wire:navigate' => true]; ?>
<?php $__slotsffc832528375aae4305fa486cda07ac2 = []; ?>
<?php $__blaze->pushData($__attrsffc832528375aae4305fa486cda07ac2); ?>
<?php ob_start(); ?><?php echo e(__('Appearance')); ?><?php $__slotsffc832528375aae4305fa486cda07ac2['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsffc832528375aae4305fa486cda07ac2); ?>
<?php _ffc832528375aae4305fa486cda07ac2($__blaze, $__attrsffc832528375aae4305fa486cda07ac2, $__slotsffc832528375aae4305fa486cda07ac2, ['href', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackffc832528375aae4305fa486cda07ac2)) { $__slotsffc832528375aae4305fa486cda07ac2 = array_pop($__slotsStackffc832528375aae4305fa486cda07ac2); } ?>
<?php if (! empty($__attrsStackffc832528375aae4305fa486cda07ac2)) { $__attrsffc832528375aae4305fa486cda07ac2 = array_pop($__attrsStackffc832528375aae4305fa486cda07ac2); } ?>
<?php $__blaze->popData(); ?>
        <?php echo trim(ob_get_clean()); ?>

</nav>
<?php $__blaze->popData(); $__env->popConsumableComponentData(); ?><?php echo ltrim(ob_get_clean()); ?>
    </div>

    <?php ob_start(); ?><div data-orientation="horizontal" role="none" class="border-0 [print-color-adjust:exact] bg-zinc-800/15 dark:bg-white/20 h-px w-full md:hidden" data-flux-separator></div>
<?php echo ltrim(ob_get_clean()); ?>

    <div class="flex-1 self-stretch max-md:pt-6">
        <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-sm [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?><?php echo e($heading ?? ''); ?><?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
        <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70" data-flux-subheading>
    <?php ob_start(); ?><?php echo e($subheading ?? ''); ?><?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>

        <div class="mt-5 w-full max-w-lg">
            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\hamza\resources\views/components/settings/layout.blade.php ENDPATH**/ ?>
<?php
if (!function_exists('_d27b62ec8b02bc0a4bd036948fa77bea')):
function _d27b62ec8b02bc0a4bd036948fa77bea($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'iconVariant' => 'mini',
    'size' => null,
];
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$size ??= $attributes['size'] ?? $__defaults['size']; unset($attributes['size']);
unset($__defaults);
?>

<?php
$attributes = $attributes->merge([
    'variant' => 'subtle',
    'class' => '-me-1',
    'square' => true,
    'size' => null,
]);
?>

<?php if (!function_exists('_e1da437d716e1318981ce19c7bc0deeb')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/e1da437d716e1318981ce19c7bc0deeb.php'); require $__blaze->compiledPath.'/e1da437d716e1318981ce19c7bc0deeb.php'; } ?>
<?php if (isset($__slotse1da437d716e1318981ce19c7bc0deeb)) { $__slotsStacke1da437d716e1318981ce19c7bc0deeb[] = $__slotse1da437d716e1318981ce19c7bc0deeb; } ?>
<?php if (isset($__attrse1da437d716e1318981ce19c7bc0deeb)) { $__attrsStacke1da437d716e1318981ce19c7bc0deeb[] = $__attrse1da437d716e1318981ce19c7bc0deeb; } ?>
<?php $__attrse1da437d716e1318981ce19c7bc0deeb = ['attributes' => $attributes,'size' => $size === 'sm' || $size === 'xs' ? 'xs' : 'sm','xData' => 'fluxInputViewable','xOn:click' => 'toggle()','xBind:dataViewableOpen' => 'open','ariaLabel' => e(__('Toggle password visibility'))]; ?>
<?php $__slotse1da437d716e1318981ce19c7bc0deeb = []; ?>
<?php $__blaze->pushData($__attrse1da437d716e1318981ce19c7bc0deeb); ?>
<?php ob_start(); ?>
    <?php if (!function_exists('_0871885db6471838ac699fd41a7b3326')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye-slash.blade.php', $__blaze->compiledPath.'/0871885db6471838ac699fd41a7b3326.php'); require $__blaze->compiledPath.'/0871885db6471838ac699fd41a7b3326.php'; } ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block']); ?>
<?php _0871885db6471838ac699fd41a7b3326($__blaze, ['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
    <?php if (!function_exists('_b3caf49f96392d88ea35f1fbf8f183b1')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye.blade.php', $__blaze->compiledPath.'/b3caf49f96392d88ea35f1fbf8f183b1.php'); require $__blaze->compiledPath.'/b3caf49f96392d88ea35f1fbf8f183b1.php'; } ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden']); ?>
<?php _b3caf49f96392d88ea35f1fbf8f183b1($__blaze, ['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
<?php $__slotse1da437d716e1318981ce19c7bc0deeb['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotse1da437d716e1318981ce19c7bc0deeb); ?>
<?php _e1da437d716e1318981ce19c7bc0deeb($__blaze, $__attrse1da437d716e1318981ce19c7bc0deeb, $__slotse1da437d716e1318981ce19c7bc0deeb, ['attributes', 'size'], ['xData' => 'x-data', 'xOn:click' => 'x-on:click', 'xBind:dataViewableOpen' => 'x-bind:data-viewable-open', 'ariaLabel' => 'aria-label'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke1da437d716e1318981ce19c7bc0deeb)) { $__slotse1da437d716e1318981ce19c7bc0deeb = array_pop($__slotsStacke1da437d716e1318981ce19c7bc0deeb); } ?>
<?php if (! empty($__attrsStacke1da437d716e1318981ce19c7bc0deeb)) { $__attrse1da437d716e1318981ce19c7bc0deeb = array_pop($__attrsStacke1da437d716e1318981ce19c7bc0deeb); } ?>
<?php $__blaze->popData(); ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/input/viewable.blade.php ENDPATH**/ ?>
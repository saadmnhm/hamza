<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1789478109} ?>
<?php # [BlazeFolded]:{flux::subheading}:{C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1789478109} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1789478109} ?>
<?php # [BlazeFolded]:{flux::text}:{C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/text.blade.php}:{1789478109} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1789478109} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1789478109} ?>
<!-- Document Generation Rubrique -->
<div class="mb-8">
    <?php ob_start(); ?><div class="border [:where(&amp;)]:bg-white [:where(&amp;)]:border-zinc-200 dark:[:where(&amp;)]:bg-white/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:p-6 [:where(&amp;)]:rounded-xl [--flux-bleed:1.5rem]" data-flux-card>
    <?php ob_start(); ?>
        <?php ob_start(); ?><h2 class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-2xl [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Génération de documents<?php echo trim(ob_get_clean()); ?></h2>

        <?php echo ltrim(ob_get_clean()); ?>
        <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70" data-flux-subheading>
    <?php ob_start(); ?>Créez des documents imprimables professionnels pour vos besoins RH et comptabilité<?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
        
        <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 px-4 py-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <a
                href="<?php echo e(route('documents.' . $type->value)); ?>"
                wire:navigate
                class="group block rounded-xl border-2 border-transparent hover:border-primary transition-colors duration-150 flex flex-col items-center justify-center"
            >
                <?php ob_start(); ?><div class="border [:where(&amp;)]:bg-white [:where(&amp;)]:border-zinc-200 dark:[:where(&amp;)]:bg-white/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:p-6 [:where(&amp;)]:rounded-xl [--flux-bleed:1.5rem] h-full p-6 text-center transition-all duration-150 group-hover:bg-primary/5 group-hover:text-primary" data-flux-card>
    <?php ob_start(); ?>
                    <div class="size-12 mx-auto mb-3 text-primary">
                        <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::icon", ['name' => $type->icon(), 'class' => 'size-6']); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php if (!function_exists('_b818240420d205fb85c457a5f0251124')) { $__blaze->compile('C:\xampp\htdocs\hamza\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/b818240420d205fb85c457a5f0251124.php'); require $__blaze->compiledPath.'/b818240420d205fb85c457a5f0251124.php'; } ?>
<?php $__blaze->pushData(['name' => $type->icon(),'class' => 'size-6']); ?>
<?php _b818240420d205fb85c457a5f0251124($__blaze, ['name' => $type->icon(),'class' => 'size-6'], [], ['name'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
                    </div>
                    
                    <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-sm [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2 text-sm font-medium mb-1" data-flux-heading><?php ob_start(); ?><?php echo e($type->title()); ?><?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
                    <?php ob_start(); ?><p class="[:where(&amp;)]:font-normal text-xs [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 text-zinc-500 line-clamp-2" data-flux-text ><?php ob_start(); ?><?php echo e($type->description()); ?><?php echo trim(ob_get_clean()); ?></p><?php echo ltrim(ob_get_clean()); ?>
                <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
            </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
</div><?php /**PATH C:\xampp\htdocs\hamza\resources\views/livewire/documents/list.blade.php ENDPATH**/ ?>
# AGENTS.md

Laravel 13 + Livewire 4 + Flux 2 application for company administration (Moroccan fiscal fields: ICE, IF, CNSS, RC, patente). Business UI copy is French; the starter-kit auth/settings screens are English.

## Commands

- Initial setup: `composer run setup` (creates `.env`, app key, runs migrations, `npm install`, `npm run build`).
- Setup does not seed. Registration is disabled, so run `php artisan db:seed` to get the `test@example.com` / `password` login, or create a user another way.
- Run `php artisan storage:link` once if company-logo uploads are needed; it is **not** part of `composer run setup`.
- Dev server: `composer run dev` (runs `php artisan dev`). Frontend-only: `npm run dev`; production build: `npm run build`. Both use `vite-plus` (`vp`), not a plain `vite` binary.
- A stale `public/hot` (currently `http://[::1]:5173`) overrides built assets; delete it or start `npm run dev` if the UI loads without CSS/JS.
- Tests: `php artisan test --compact`; single file: `php artisan test --compact tests/Feature/DashboardTest.php`; single test: add `--filter="test name"`.
- Format changed PHP: `vendor/bin/pint --dirty --format agent`. Format everything: `composer lint`.
- Static analysis: `composer types:check` (Larastan/PHPStan level 7 over `app/`, `bootstrap/app.php`, `config/`, `database/`, `routes/`).
- Full gate: `composer test` = `config:clear` -> `pint --test` -> `phpstan` -> `php artisan test`. There is no CI workflow; this is the verification command.
- On PowerShell, quote tinker code with single quotes and use double quotes for PHP strings: `php artisan tinker --execute 'User::where("active", true)->count();'`

## Architecture

- Single Laravel app; no API routes. `routes/web.php` holds business pages, `routes/settings.php` holds profile/security/appearance, and Fortify registers auth routes from `config/fortify.php`.
- Business pages are class-based Livewire components in `app/Livewire/<Domain>/<Name>.php` with views under `resources/views/livewire/<domain>/`. View names do not always match the class: `RolesList` renders `roles/list.blade.php`, `Utilisateurs` renders `utilisateurs/users.blade.php`. Volt is not installed; do not create Volt components.
- Both route styles are in use: `Route::livewire(...)` in `routes/settings.php` and `Route::get(Component::class)` in `routes/web.php`. Match the file you edit.
- Full-page Livewire components are wrapped by `layouts::app` (`resources/views/layouts/app.blade.php`, which includes the sidebar); add navigation entries in `resources/views/layouts/app/sidebar.blade.php`.
- Auth is Fortify. Login/reset/verify pages are plain Blade views under `resources/views/livewire/auth/`, wired in `app/Providers/FortifyServiceProvider.php` — there are no `app/Livewire/Auth/*` classes. Only password reset and email verification are enabled; registration, two-factor, and passkeys are disabled (leftover 2FA wiring in `Security` is inert). Create users via `DatabaseSeeder`/`UserFactory`.
- UI is Flux 2 (`<flux:*>`) + Tailwind 4. Only the free `livewire/flux` package is installed; Flux Pro-only components will fail. Checked-in Flux overrides live in `resources/views/flux/`.
- `App\Models\User` implements `MustVerifyEmail` and uses Laravel 13 `#[Fillable]`/`#[Hidden]` attributes instead of `$fillable`/`$hidden`.

## Testing

- Pest 5. Feature tests automatically use `RefreshDatabase` via `tests/Pest.php`; the test DB is in-memory SQLite (`phpunit.xml`), so no external services are needed.
- Create tests with `php artisan make:test --pest SomeFeatureTest`; do not prefix the name with `Feature/`.
- Use `Livewire::test(Component::class)` for component actions, as in `tests/Feature/Settings/ProfileUpdateTest.php`.
- Add or update tests for behavior changes; pure copy/layout changes do not require tests. Do not delete tests without approval.
- Existing feature coverage is starter-kit auth/settings/dashboard plus placeholder `ExampleTest`s. The Config/Utilisateurs/Roles pages have no tests; add Livewire tests when changing their behavior.

## Current baseline / traps (2026-10-29)

- The worktree contains uncommitted company-config WIP. Do not revert it.
- `php artisan test` currently has 1 failure: `tests/Feature/ExampleTest.php` expects `GET /` to return 200, but `route('home')` redirects to login. This is pre-existing, not necessarily your regression.
- `composer lint:check` and `composer types:check` currently fail on that WIP (untyped Livewire properties, `ConfigFactory` missing, migration issues). Use targeted tests plus `pint --dirty` while working there.
- `app/Models/Config` references `Database\Factories\ConfigFactory`, which does not exist.
- `App\Livewire\Config\Config::render()` contains a `$_GET['ddd']` dump-and-exit debug block; remove it before shipping.
- The `configs` migration's `down()` drops `company_configs`, not `configs`, so rollback will not remove the table.
- `app/Helpers/helpers.php` (global `getList`) is not in Composer's `autoload.files` and will not load automatically. A duplicate `Builder::getList` macro exists in `AppServiceProvider`, and `Config::render()` calls a nonexistent static `configs::getList()`. Do not assume either implementation is active.
- `AppServiceProvider` sets `Date::use(CarbonImmutable::class)` and applies production-only password rules (min 12, mixed case, numbers, symbols, uncompromised). Local/test password validation differs from production.
- Composer requires PHP `^8.3` even though the local CLI is 8.5; keep committed code 8.3-compatible.

## Conventions and tooling

- Use `php artisan make:*` to scaffold files and follow sibling files for naming/structure. Do not add dependencies without approval.
- Use named routes with `route()`; do not hard-code URLs.
- Load the matching skill before domain work: `laravel-best-practices`, `livewire-development`, `fluxui-development`, `fortify-development`, `tailwindcss-development`, `testing-best-practices`, or `deploying-to-cloud`.
- Laravel Boost is installed, but `.mcp.json` is Claude Code configuration and there is no `opencode.json`. OpenCode sessions may not have `search-docs`/`database-query` tools; use Artisan commands and direct file reads instead.
